# notes-app

## How to Run

- [Download](https://nodejs.org/en) and Install Node.JS
- Clone this repository
```bash
  git clone https://github.com/Perwira-AZ/notes-app.git
```
- Install dependencies
```bash
  npm install
```
- Run the app
```bash
  npm run dev
```
