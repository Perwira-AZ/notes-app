import React from 'react';

function ErrorPage() {
    return (
        <section>
            <h2>404</h2>
            <p>Page Not Found</p>
        </section>
    );
}

export default ErrorPage;
